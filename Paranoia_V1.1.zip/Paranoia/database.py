import aiosqlite
import os
import json

DB_NAME = "conversations.db"
CONVERSATIONS_DIR = "conversation_history"  # Directory to store text files

async def initialize_db():
    """Creates the conversations table if it doesn't exist."""
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS conversations (
                user_id TEXT PRIMARY KEY,
                chat_id TEXT
            )
        """)
        await db.commit()

    # Create the directory if it doesn't exist
    os.makedirs(CONVERSATIONS_DIR, exist_ok=True)

async def save_chat_session(user_id, chat_id, conversation_history):
    """Saves chat session ID to the database and conversation history to a file."""

    # Save chat_id to database (same as before)
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("""
            INSERT INTO conversations (user_id, chat_id)
            VALUES (?, ?)
            ON CONFLICT(user_id) DO UPDATE SET chat_id = excluded.chat_id
        """, (user_id, chat_id))
        await db.commit()


    # Save conversation history to a file
    filename = os.path.join(CONVERSATIONS_DIR, f"{user_id}.txt")
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(conversation_history, f)  # Store as JSON for easier handling

async def get_chat_session(user_id):
    """Retrieves chat session ID and conversation history."""
    async with aiosqlite.connect(DB_NAME) as db:
        async with db.execute("SELECT chat_id FROM conversations WHERE user_id = ?", (user_id,)) as cursor:
            row = await cursor.fetchone()
            chat_id = row[0] if row else None

    conversation_history = []
    filename = os.path.join(CONVERSATIONS_DIR, f"{user_id}.txt")
    if os.path.exists(filename):
        try:
            with open(filename, "r", encoding="utf-8") as f:
                conversation_history = json.load(f) # Load from JSON
        except json.JSONDecodeError:
            print(f"Warning: Could not decode JSON in {filename}. Starting with empty history.")

    return chat_id, conversation_history

# Example Usage (in your CharacterAI interaction function):

async def handle_characterai_command(user_id, message):
    # ... (other code)

    chat_id, conversation_history = await get_chat_session(user_id) # Get history

    if not chat_id:  # New session
        # ... (create new chat_id)
        conversation_history = []  # Initialize empty history

    # Include conversation history in the message
    full_message = "\n".join(conversation_history + [message])  # Combine history and current message

    # ... (send message to CharacterAI)

    # Update and save conversation history
    conversation_history.append(f"You: {message}")
    conversation_history.append(f"Hu Tao: {response.text}")
    await save_chat_session(user_id, chat_id, conversation_history)  # Save to file

    return response.text