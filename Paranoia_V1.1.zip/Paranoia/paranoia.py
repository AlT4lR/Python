import tkinter as tk
from tkinter import messagebox # explicitly import
from PIL import Image, ImageTk, ImageDraw
import asyncio
from characterai import aiocai
from database import initialize_db, save_chat_session, get_chat_session  # Import DB functions
import random
import datetime  # Import datetime module
import subprocess  # For installing libraries
import importlib  # For checking if libraries are installed
import sys # For safely closing the program

# --- Hu Tao Color Scheme ---
HU_TAO_RED = "#FF4500"       # A vibrant reddish-orange
HU_TAO_MESSAGE = "#FFB347"  # Light Coral/Orange for Messages
HU_TAO_WHITE = "#FFFAFA"       # Snow white
HU_TAO_DARK = "#333333"      # Dark Gray for contrast

# --- CharacterAI Setup ---
client = aiocai.Client('8d9d7d0d89c48642e440e66e2590256f7dc0e3ef')  # Replace with your actual key
USER_NAME = "Altair"  # Define the user's name
IDLE_TIMEOUT = 30  # seconds
CHAR_ID = "U3dJdreV9rrvUiAnILMauI-oNH838a8E_kEYfOFPalE"  # Your character ID

# --- Conversation Topics ---
HU_TAO_TOPICS = [
    "funeral arrangements",
    "ghost stories",
    "the best coffins",
    "the afterlife",
    "Wangsheng Funeral Parlor discounts",
    "interesting local customs",
    "poems about death",
    "recent strange occurrences in Liyue",
    "different types of ghosts"
]

# --- Tkinter Setup ---
root = tk.Tk()  # Create root here, even if it's temporary
root.title("Director Hu Tao")
root.geometry("800x600") # You can set the geometry before library check

# Set background color of the root window
root.configure(bg=HU_TAO_DARK)

# --- Flags for graceful shutdown ---
running = True  # Global flag to control the main loop
last_interaction_time = asyncio.get_event_loop().time()  # Initialize last interaction time

# --- Frames ---
main_frame = tk.Frame(root, bg=HU_TAO_DARK)  # Set frame background
main_frame.pack(fill=tk.BOTH, expand=True)

# --- Chat Log ---
chat_frame = tk.Frame(main_frame, bg=HU_TAO_DARK)  # Set frame background
chat_frame.pack(fill=tk.BOTH, expand=True)

chat_log = tk.Text(chat_frame, bg=HU_TAO_DARK, fg=HU_TAO_WHITE, wrap=tk.WORD, state=tk.DISABLED)  # Use Hu Tao colors
chat_log.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

# --- Input Area ---
input_frame = tk.Frame(root, bg=HU_TAO_DARK)  # Set frame background
input_frame.pack(side=tk.BOTTOM, fill=tk.X)

message_entry = tk.Entry(input_frame, bg=HU_TAO_DARK, fg=HU_TAO_WHITE, font=("Courier New", 12), insertbackground=HU_TAO_WHITE)  # Use Hu Tao colors
message_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=10, pady=10)

send_button = tk.Button(input_frame, text="Send", bg=HU_TAO_RED, fg=HU_TAO_WHITE, font=("Arial", 12), padx=10, pady=5)  # Use Hu Tao colors
send_button.pack(side=tk.RIGHT, padx=10, pady=10)

# --- Hu Tao Info ---
info_frame = tk.Frame(chat_frame, bg=HU_TAO_DARK)  # Set frame background
info_frame.pack(side=tk.TOP, fill=tk.X)

def create_circular_image(image_path, size):
    """Create a circular image from the given image path."""
    # Open the image and resize it
    image = Image.open(image_path).resize(size)

    # Create a mask for the circular shape
    mask = Image.new("L", size, 0)
    draw = ImageDraw.Draw(mask)
    draw.ellipse((0, 0, size[0], size[1]), fill=255)

    # Apply the mask to the image
    circular_image = Image.new("RGBA", size)
    circular_image.paste(image, (0, 0), mask=mask)

    return circular_image

try:
    img_path = "assets/hutao.jpg"  # Ensure the image path is correct
    circular_image = create_circular_image(img_path, (75, 75))  # Create circular image
    photo = ImageTk.PhotoImage(circular_image)
    image_label = tk.Label(info_frame, image=photo, bg=HU_TAO_DARK)  # Set background color
    image_label.image = photo
    image_label.pack(side=tk.LEFT, padx=10, pady=10)
except FileNotFoundError:
    print(f"Image not found: {img_path}")

name_label = tk.Label(info_frame, text="Hu Tao", font=("Baskerville", 22), bg=HU_TAO_DARK, fg=HU_TAO_RED)  # Use Hu Tao colors
name_label.pack(side=tk.LEFT, pady=10)

# --- CharacterAI Functions with DB Integration ---
async def handle_characterai_command(user_id, message):
    try:
        chat_id, conversation_history = await get_chat_session(user_id)
        chat = await client.connect()  # Connect *once* per message

        # Get current time and date
        now = datetime.datetime.now()
        current_time = now.strftime("%H:%M")
        current_date = now.strftime("%Y-%m-%d")

        # Construct a prompt that tells the bot the time and date
        context = f"The current time is {current_time} on {current_date}. "
        message_with_context = context + message

        if not chat_id:
            # Add the initial message to the beginning of the conversation
            initial_message = "Heya. I'm the 77th Director of the Wangsheng Funeral Parlor, Hu Tao. Are you one of my clients?"
            new_chat, _ = await chat.new_chat(CHAR_ID, (await client.get_me()).id)
            chat_id = new_chat.chat_id
            await save_chat_session(user_id, chat_id, [f"Hu Tao: {initial_message}"])  # Save initial message

        # Send message with history
        full_message = "\n".join(conversation_history + [message_with_context]) if conversation_history else message_with_context
        response = await chat.send_message(CHAR_ID, chat_id, full_message)

        conversation_history.append(f"{USER_NAME}: {message}") # use defined USER_NAME
        conversation_history.append(f"Hu Tao: {response.text}")
        await save_chat_session(user_id, chat_id, conversation_history)

        return response.text

    except Exception as e:
        print(f"Error generating content: {e}")
        return f"Error: {e}"

# --- Chat Handling ---
def update_chat_log(message, sender="user"):
    chat_log.config(state=tk.NORMAL)
    if sender == "hutao":
        chat_log.insert(tk.END, message + "\n", "hutao")
    else:
        chat_log.insert(tk.END, message + "\n")
    chat_log.tag_config("hutao", foreground=HU_TAO_MESSAGE)  # Pale Orange for Hu Tao
    chat_log.see(tk.END)
    chat_log.config(state=tk.DISABLED)

def send_message():
    global last_interaction_time
    user_message = message_entry.get().strip()
    if user_message:
        update_chat_log(f"{USER_NAME}: {user_message}") # use defined USER_NAME
        message_entry.delete(0, tk.END)
        asyncio.create_task(process_response(user_message))
        last_interaction_time = asyncio.get_event_loop().time()  # Update last interaction time

async def process_response(message):
    global last_interaction_time
    user_id = 1  # Simulated user ID since this is a local app
    response = await handle_characterai_command(user_id, message)
    update_chat_log(f"Hu Tao: {response}", sender="hutao")
    display_conversation() # Update conversation
    last_interaction_time = asyncio.get_event_loop().time()  # Update last interaction time

def display_conversation():
    """Displays the full conversation history in the chat log."""
    async def _display_conversation():
        user_id = 1
        chat_id, conversation_history = await get_chat_session(user_id)

        # Temporarily enable the chat log for editing
        chat_log.config(state=tk.NORMAL)
        chat_log.delete("1.0", tk.END)  # Clear the entire chat log

        # Loop through the conversation history and display it
        for line in conversation_history:
           if line.startswith("Hu Tao:"):
               # Ensure "Hu Tao:" lines get the correct formatting and color
               message = line  # The full message to display (e.g., "Hu Tao: Hello!")
               update_chat_log(message, sender="hutao")
           else:
               message = line
               update_chat_log(message)

        # Disable the chat log again
        chat_log.config(state=tk.DISABLED)
        chat_log.see(tk.END)  # Scroll to the end

    asyncio.create_task(_display_conversation())

async def generate_idle_response(user_id):
    """Generates a dynamic idle response, sometimes suggesting topics."""
    try:
        chat_id, conversation_history = await get_chat_session(user_id)
        chat = await client.connect()

        # Get current time and date
        now = datetime.datetime.now()
        current_time = now.strftime("%H:%M")
        current_date = now.strftime("%Y-%m-%d")

        if not chat_id:  # New session
            new_chat, _ = await chat.new_chat(CHAR_ID, (await client.get_me()).id)
            chat_id = new_chat.chat_id
            await save_chat_session(user_id, chat_id, [])

        context = f"The current time is {current_time} on {current_date}. "

        # 50% chance to suggest a topic
        if random.random() < 0.5:
            topic = random.choice(HU_TAO_TOPICS)
            prompt = context + f"The user has been idle for a while. Suggest the following topic to the user, phrased in a playful, Hu Tao-like way: {topic}.  Do not ask if they need help or are still there. Keep the message short."
        else:
            prompt = context + "The user has been idle for a while. Generate a short, lore-appropriate message from Hu Tao to re-engage them. Do not ask if they need help or are still there. Keep the message short."

        full_message = "\n".join(conversation_history + [prompt]) if conversation_history else prompt

        response = await chat.send_message(CHAR_ID, chat_id, full_message)  # Send the new prompt
        return response.text

    except Exception as e:
        print(f"Error generating idle response: {e}")
        return "Boo! Did I scare you?"  # Default fallback

# --- Shutdown Handling ---
async def shutdown():
    """Close resources and perform cleanup before exiting."""
    print("Shutting down...")
    # Add your cleanup code here, e.g., closing database connections, etc.
    try:
        if hasattr(client, 'close') and callable(client.close):  # Check if close is a method
            await client.close()
            print("CharacterAI client closed")
    except Exception as e:
        print(f"Error closing client: {e}")

    print("Shutdown complete.")

def on_closing():
    """Handles the window closing event."""
    global running
    running = False  # Signal to stop the main loop
    print("Closing application...")

    async def _close():
        await shutdown()  # Await the shutdown coroutine
        root.destroy()  # Destroy the Tkinter window

    asyncio.create_task(_close())  # Run the async close operation
    # No need to asyncio.get_event_loop().stop() here; root.destroy() will trigger it


send_button.config(command=send_message)
message_entry.bind("<Return>", lambda event: send_message())

# Register the closing protocol
root.protocol("WM_DELETE_WINDOW", on_closing)

# --- Tkinter with Asyncio Support ---
async def main():

    # --- Library Checking and Installation ---
    required_libraries = ['tkinter', 'PIL', 'asyncio', 'characterai', 'sqlite3']  #sqlite3 for DB
    missing_libraries = []

    for lib in required_libraries:
        try:
            importlib.import_module(lib)
        except ImportError:
            missing_libraries.append(lib)

    if missing_libraries:
        print("Missing libraries: ", missing_libraries)
        print("Attempting to install...")
        try:
            subprocess.check_call(['pip', 'install', *missing_libraries])  # Install all at once
            print("Libraries installed successfully!")

            # Give user instruction to restart to be safe
            messagebox.showinfo("Restart Required", "Please restart the application for the changes to take effect.")

            # Properly quit the application after install and restart
            root.destroy()
            sys.exit()

        except subprocess.CalledProcessError as e:
            print(f"Error installing libraries: {e}")
            messagebox.showerror("Error", f"Failed to automatically install libraries. Please install them manually:\n{e}")

            # Properly quit the application after displaying error
            root.destroy()
            sys.exit()
    else:
        print("All required libraries are installed.")


    await initialize_db()
    global client, last_interaction_time
    client = aiocai.Client('8d9d7d0d89c48642e440e66e2590256f7dc0e3ef')  # Replace with your actual key
    user_id = 1  # Simulated user ID since this is a local app
    chat_id, _ = await get_chat_session(user_id)

    # Check if the client has a close method
    if hasattr(client, 'close') and callable(client.close):
        print("client has close method")
    else:
        print("client doesn't have close method")


    while running:
        # Check for new chat_id
        user_id = 1  # Simulated user ID since this is a local app
        chat_id, _ = await get_chat_session(user_id)

        if not chat_id:
            initial_message = "Heya. I'm the 77th Director of the Wangsheng Funeral Parlor, Hu Tao. Are you one of my clients?"
            update_chat_log(f"Hu Tao: {initial_message}", sender="hutao")

        try:
            current_time = asyncio.get_event_loop().time()
            if current_time - last_interaction_time > IDLE_TIMEOUT:
                # Trigger idle chat
                last_interaction_time = current_time  # Reset timer to avoid repeat triggers

                # Generate dynamic idle response
                idle_message = await generate_idle_response(user_id)

                # Save to DB
                chat_id, conversation_history = await get_chat_session(user_id)
                conversation_history.append(f"Hu Tao: {idle_message}")
                await save_chat_session(user_id, chat_id, conversation_history)

                # Display to chat log
                update_chat_log(f"Hu Tao: {idle_message}", sender="hutao")

                display_conversation()


            root.update()
            await asyncio.sleep(0.01)
        except tk.TclError:
            break

    print("Main loop terminated.")


if __name__ == "__main__":
    asyncio.run(main())