import aiosqlite
import json # Import json for storing conversation

DB_NAME = "conversations.db"

async def initialize_db():
    """Creates the conversation table if it doesn't exist."""
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS conversations (
                user_id TEXT PRIMARY KEY,
                chat_id TEXT,
                conversation_history TEXT
            )
        """)
        await db.commit()

async def save_chat_session(user_id, chat_id, conversation_history):
    """Saves or updates a user's chat session in the database, including history."""
    async with aiosqlite.connect(DB_NAME) as db:
        # Convert the conversation history to a JSON string before saving
        conversation_json = json.dumps(conversation_history)

        await db.execute("""
            INSERT INTO conversations (user_id, chat_id, conversation_history)
            VALUES (?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET chat_id = excluded.chat_id, conversation_history = excluded.conversation_history
        """, (user_id, chat_id, conversation_json))
        await db.commit()

async def get_chat_session(user_id):
    """Retrieves the chat session ID and conversation history of a user."""
    async with aiosqlite.connect(DB_NAME) as db:
        async with db.execute("SELECT chat_id, conversation_history FROM conversations WHERE user_id = ?", (user_id,)) as cursor:
            row = await cursor.fetchone()
            if row:
                chat_id, conversation_json = row
                # Convert the JSON string back to a list
                conversation_history = json.loads(conversation_json) if conversation_json else []
                return chat_id, conversation_history
            else:
                return None, []  # Return None, [] if no chat session exists