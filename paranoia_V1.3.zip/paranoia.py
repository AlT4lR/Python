import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk, ImageDraw
import asyncio
from characterai import aiocai
from database import initialize_db, save_chat_session, get_chat_session
import random
import datetime
import subprocess
import importlib
import sys
from textblob import TextBlob  # For sentiment analysis

# --- Hu Tao Color Scheme ---
HU_TAO_RED = "#FF4500"
HU_TAO_MESSAGE = "#FFB347"
HU_TAO_WHITE = "#FFFAFA"
HU_TAO_DARK = "#333333"

# --- CharacterAI Setup ---
client = aiocai.Client('8d9d7d0d89c48642e440e66e2590256f7dc0e3ef')  # Replace with your key
USER_NAME = "Altair" # Initial username. Change it here for testing, otherwise starts as "Altair"
DEFAULT_USER_NAME = "Altair"
IDLE_TIMEOUT = 180  # seconds
CHAR_ID = "U3dJdreV9rrvUiAnILMauI-oNH838a8E_kEYfOFPalE"  # Replace with your character ID

# --- Conversation Topics ---
HU_TAO_TOPICS = [
    "funeral arrangements",
    "ghost stories",
    "the best coffins",
    "the afterlife",
    "Wangsheng Funeral Parlor discounts",
    "interesting local customs",
    "poems about death",
    "recent strange occurrences in Liyue",
    "different types of ghosts"
]

# --- Hu Tao Activities ---
HU_TAO_ACTIVITIES = [
    "practicing polearm techniques in the courtyard",
    "sampling new coffin designs",
    "writing morbid poems",
    "bargaining with grave robbers for discounts",
    "playing pranks on Qiqi",
    "planning upcoming funeral events",
    "meditating on the balance of life and death",
    "drinking tea and contemplating mortality"
]

# --- Activity Progression ---
ACTIVITY_DURATION = 60  # seconds (how long an activity takes)
current_activity = None
activity_start_time = None

# --- Emotion Recognition Setup ---
EMOTIONS = ["Happy", "Sad", "Angry", "Fearful", "Surprised", "Neutral", "Disgusted", "Worried", "Loving", "Obsessed", "Endearing"] # Extended List
emotion_label = None  # Placeholder
current_emotion = "Neutral"  # Default emotion
EMOTION_COLORS = {
    "Happy": "#FFD700",     # Gold
    "Sad": "#87CEEB",       # Sky Blue
    "Angry": "#FF4500",     # Orange Red
    "Fearful": "#90EE90",   # Light Green
    "Surprised": "#DDA0DD",  # Plum
    "Neutral": "#FFFFFF",   # White
    "Disgusted": "#8B4513",  # Saddle Brown
    "Worried": "#A9A9A9",   # Dark Gray
    "Loving": "#FF69B4",    # Hot Pink
    "Obsessed": "#800080",  # Purple
    "Endearing": "#FFA07A",   # Light Salmon
}

# --- Affection System ---
DEFAULT_AFFECTION = 50
MAX_AFFECTION = 100
MIN_AFFECTION = 0
AFFECTION_CHANGE_AMOUNT = 5  # Adjust the amount of affection change per interaction
user_affection = DEFAULT_AFFECTION #Initialize the user's affection

# --- Tkinter Setup ---
root = tk.Tk()
root.title("Director Hu Tao")
root.geometry("800x600")
root.configure(bg=HU_TAO_DARK)

# --- Flags ---
running = True
last_interaction_time = asyncio.get_event_loop().time()
user_introduced = False  # Flag to track if the user has introduced themselves

# --- Frames ---
main_frame = tk.Frame(root, bg=HU_TAO_DARK)
main_frame.pack(fill=tk.BOTH, expand=True)

chat_frame = tk.Frame(main_frame, bg=HU_TAO_DARK)
chat_frame.pack(fill=tk.BOTH, expand=True)

chat_log = tk.Text(chat_frame, bg=HU_TAO_DARK, fg=HU_TAO_WHITE, wrap=tk.WORD, state=tk.DISABLED)
chat_log.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

input_frame = tk.Frame(root, bg=HU_TAO_DARK)
input_frame.pack(side=tk.BOTTOM, fill=tk.X)

message_entry = tk.Entry(input_frame, bg=HU_TAO_DARK, fg=HU_TAO_WHITE, font=("Courier New", 12), insertbackground=HU_TAO_WHITE)
message_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=10, pady=10)

send_button = tk.Button(input_frame, text="Send", bg=HU_TAO_RED, fg=HU_TAO_WHITE, font=("Arial", 12), padx=10, pady=5)
send_button.pack(side=tk.RIGHT, padx=10, pady=10)

# --- Hu Tao Info ---
info_frame = tk.Frame(chat_frame, bg=HU_TAO_DARK)
info_frame.pack(side=tk.TOP, fill=tk.X)

def create_circular_image(image_path, size):
    image = Image.open(image_path).resize(size)
    mask = Image.new("L", size, 0)
    draw = ImageDraw.Draw(mask)
    draw.ellipse((0, 0, size[0], size[1]), fill=255)
    circular_image = Image.new("RGBA", size)
    circular_image.paste(image, (0, 0), mask=mask)
    return circular_image

try:
    img_path = "assets/hutao.jpg"
    circular_image = create_circular_image(img_path, (75, 75))
    photo = ImageTk.PhotoImage(circular_image)
    image_label = tk.Label(info_frame, image=photo, bg=HU_TAO_DARK)
    image_label.image = photo
    image_label.pack(side=tk.LEFT, padx=10, pady=10)
except FileNotFoundError:
    print(f"Image not found: {img_path}")

name_label_frame = tk.Frame(info_frame, bg=HU_TAO_DARK)
name_label_frame.pack(side=tk.LEFT, pady=10)

name_label = tk.Label(name_label_frame, text="Hu Tao", font=("Baskerville", 22), bg=HU_TAO_DARK, fg=HU_TAO_RED)
name_label.pack(side=tk.TOP)

version_label = tk.Label(name_label_frame, text="by Altair, Version 1.3", font=("Arial", 10), bg=HU_TAO_DARK, fg=HU_TAO_WHITE)
version_label.pack(side=tk.TOP)

# --- Emotion Label Setup ---
emotion_label = tk.Label(info_frame, text=f"{current_emotion}", font=("Arial", 12), bg=HU_TAO_DARK, fg=EMOTION_COLORS[current_emotion])  # Set initial color
emotion_label.pack(side=tk.RIGHT, padx=10)

# --- Helper Functions ---
def choose_activity():
    """Selects a new activity for Hu Tao."""
    global current_activity, activity_start_time
    current_activity = random.choice(HU_TAO_ACTIVITIES)
    activity_start_time = asyncio.get_event_loop().time()

def suggest_topic():
    """Randomly selects a new conversation topic from the list."""
    return random.choice(HU_TAO_TOPICS)

def get_activity_status():
    """Checks if the current activity is still ongoing."""
    global current_activity, activity_start_time
    if current_activity is None:
        choose_activity() #start a new activity if none exists
        return f"Just starting with {current_activity}."

    elapsed_time = asyncio.get_event_loop().time() - activity_start_time
    if elapsed_time >= ACTIVITY_DURATION:
        choose_activity() # New activity when done
        return f"Just finishing, and now onto {current_activity}."
    else:
        return f"Currently {current_activity}."

def analyze_emotion(text):
    """Basic emotion analysis using TextBlob (Sentiment analysis)."""
    analysis = TextBlob(text)
    polarity = analysis.sentiment.polarity # Ranges from -1 to 1 (negative to positive)
    subjectivity = analysis.sentiment.subjectivity # Ranges from 0 to 1 (objective to subjective)

    if polarity > 0.5:
        return "Happy"
    elif polarity < -0.5:
        return "Sad"  #Could be angry or disgusted, but defaulting to sad
    elif subjectivity > 0.7:
        return "Surprised" #High subjectivity suggests surprise or worry
    elif "darling" in text.lower() or "sweetheart" in text.lower() or "dearest" in text.lower():
        return "Endearing" #Check for loving terms
    elif subjectivity < 0.3:
        return "Neutral" #Mostly objective
    else:
        return "Neutral"  #Default

def update_emotion_label(emotion):
    """Updates the emotion label in the GUI."""
    global emotion_label
    emotion_label.config(text=f"{emotion}", fg=EMOTION_COLORS.get(emotion, "#FFFFFF"))  #Update Color

def adjust_affection(amount):
    """Adjusts Hu Tao's affection towards the user, and keeps it within bounds."""
    global user_affection
    user_affection += amount
    user_affection = max(MIN_AFFECTION, min(MAX_AFFECTION, user_affection))  #Clamp the value between MIN_AFFECTION and MAX_AFFECTION

# --- CharacterAI Functions ---
async def handle_characterai_command(user_id, message):
    global current_activity, activity_start_time, current_emotion, user_affection, USER_NAME, user_introduced

    try:
        chat_id, conversation_history = await get_chat_session(user_id)
        chat = await client.connect()

        now = datetime.datetime.now()
        current_time = now.strftime("%H:%M")
        current_date = now.strftime("%Y-%m-%d")
        context = f"The current time is {current_time} on {current_date}. "

        if not chat_id:
            initial_message = "Heya. I'm the 77th Director of the Wangsheng Funeral Parlor, Hu Tao. Are you one of my clients?"
            new_chat, _ = await chat.new_chat(CHAR_ID, (await client.get_me()).id)
            chat_id = new_chat.chat_id
            conversation_history = [f"Hu Tao: {initial_message}"]
            await save_chat_session(user_id, chat_id, conversation_history)

        # Check if the user introduces themself
        if not user_introduced:
            if "I'm" in message or "I am" in message or "My name is" in message:
                try:
                    name = message.split()[-1].strip(".,?!")  # Simple extraction of name. improve name recognizance here!
                    USER_NAME = name.capitalize()
                    user_introduced = True # Sets introduced user

                except:
                   print("Error to recognizing name! Current name remain to Altair! ")

        # Check if the user asks what Hu Tao is doing
        if "what are you doing" in message.lower() or "what are you up to" in message.lower():
            activity_status = get_activity_status() # check the activity and update if needed
            conversation_history.append(f"{USER_NAME}: {message}")
            conversation_history.append(f"Hu Tao: {activity_status}")
            await save_chat_session(user_id, chat_id, conversation_history)
            return activity_status

        # Randomly suggest a new topic
        if random.random() < 0.2:  #20% chance
            suggested_topic = suggest_topic()
            topic_prompt = f"Also, how about we talk about {suggested_topic}? It's always fun to discuss, right?"
            message += " " + topic_prompt #Append topic

        # Construct a clearer prompt
        prompt = f"""You are Hu Tao, the 77th Director of the Wangsheng Funeral Parlor.
        Your goal is to have a natural, engaging, and coherent conversation with the user.
        Maintain your playful and slightly mischievous personality. Answer as Hu Tao, in character. Don't break character.

        Hu Tao's current affection level towards the user is {user_affection} out of 100.
        Previous conversation:
        {conversation_history}
        {USER_NAME}: {message}
        Hu Tao: """
        full_message = context + prompt

        response = await chat.send_message(CHAR_ID, chat_id, full_message)
        response_text = response.text

        # Basic response filtering
        if "I am an AI" in response_text or len(response_text) < 5:
            print("Filtered nonsensical response.")
            response_text = "Hehe... Let's talk about something else!"

        # Analyze emotion
        current_emotion = analyze_emotion(response_text)
        update_emotion_label(current_emotion)

        # Adjust affection based on emotion (EXAMPLE - ADJUST THESE RULES)
        if current_emotion == "Happy" or current_emotion == "Endearing":
            adjust_affection(AFFECTION_CHANGE_AMOUNT)
        elif current_emotion == "Angry" or current_emotion == "Disgusted":
            adjust_affection(-AFFECTION_CHANGE_AMOUNT)

        conversation_history.append(f"{USER_NAME}: {message}")
        conversation_history.append(f"Hu Tao: {response_text}")
        await save_chat_session(user_id, chat_id, conversation_history)

        return response_text

    except Exception as e:
        print(f"Error generating content: {e}")
        return f"Error: {e}"

# --- Chat Handling ---
def update_chat_log(message, sender="user"):
    chat_log.config(state=tk.NORMAL)
    if sender == "hutao":
        chat_log.insert(tk.END, message + "\n", "hutao")
    else:
        chat_log.insert(tk.END, message + "\n")
    chat_log.tag_config("hutao", foreground=HU_TAO_MESSAGE)
    chat_log.see(tk.END)
    chat_log.config(state=tk.DISABLED)

def send_message():
    global last_interaction_time, user_introduced

    user_message = message_entry.get().strip()

    if user_message:

        if user_introduced:  #Already Introduced
            update_chat_log(f"{USER_NAME}: {user_message}")

        else:

            update_chat_log(f"{DEFAULT_USER_NAME}: {user_message}") #start up Altair if never introduced.


        message_entry.delete(0, tk.END)
        asyncio.create_task(process_response(user_message))
        last_interaction_time = asyncio.get_event_loop().time()

async def process_response(message):
    user_id = 1
    response = await handle_characterai_command(user_id, message)
    update_chat_log(f"Hu Tao: {response}", sender="hutao")
    display_conversation()

def display_conversation():
    async def _display_conversation():
        global USER_NAME
        user_id = 1
        chat_id, conversation_history = await get_chat_session(user_id)

        chat_log.config(state=tk.NORMAL)
        chat_log.delete("1.0", tk.END)

        for line in conversation_history:
            if line.startswith("Hu Tao:"):
                update_chat_log(line, sender="hutao")

            elif line.startswith(f"{USER_NAME}:"):  # Already replaced. Use USERNAME
               update_chat_log(line) #append old record
            elif line.startswith(f"{DEFAULT_USER_NAME}:"): # if intro have yet or wrong recognized intro do!
                 update_chat_log(line) #keep showing name if dont have USER_NAME
            else:

                update_chat_log(line)


        chat_log.config(state=tk.DISABLED)
        chat_log.see(tk.END)

    asyncio.create_task(_display_conversation())

async def generate_idle_response(user_id):
    global current_emotion, user_affection
    try:
        chat_id, conversation_history = await get_chat_session(user_id)
        chat = await client.connect()

        now = datetime.datetime.now()
        current_time = now.strftime("%H:%M")
        current_date = now.strftime("%Y-%m-%d")
        context = f"The current time is {current_time} on {current_date}. "

        if not chat_id:
            new_chat, _ = await chat.new_chat(CHAR_ID, (await client.get_me()).id)
            chat_id = new_chat.chat_id
            conversation_history = []
            await save_chat_session(user_id, chat_id, conversation_history)

        if random.random() < 0.5:
            topic = random.choice(HU_TAO_TOPICS)
            prompt = f"""You are Hu Tao. The user is idle. Re-engage them by playfully suggesting the topic: {topic}. Don't ask if they need help or are there. Keep it short and in character.
            Hu Tao's current affection level towards the user is {user_affection} out of 100."""
        else:
            prompt = f"""You are Hu Tao. The user is idle. Generate a short, lore-appropriate message to re-engage them. Don't ask if they need help or are there. Also include what are you doing. Keep it short and in character.
            Hu Tao's current affection level towards the user is {user_affection} out of 100."""

        full_message = context + prompt

        response = await chat.send_message(CHAR_ID, chat_id, full_message)
        response_text = response.text

        # Basic response filtering
        if "I am an AI" in response_text or len(response_text) < 5:
            print("Filtered nonsensical response.")
            response_text = "Hehe... Are you still there?"

        # Analyze emotion
        current_emotion = analyze_emotion(response_text)
        update_emotion_label(current_emotion)

        # Adjust affection based on emotion (EXAMPLE - ADJUST THESE RULES)
        if current_emotion == "Happy" or current_emotion == "Endearing":
            adjust_affection(AFFECTION_CHANGE_AMOUNT)
        elif current_emotion == "Angry" or current_emotion == "Disgusted":
            adjust_affection(-AFFECTION_CHANGE_AMOUNT)

        conversation_history.append(f"Hu Tao: {response_text}")
        await save_chat_session(user_id, chat_id, conversation_history)

        return response_text

    except Exception as e:
        print(f"Error generating idle response: {e}")
        return "Boo! Did I scare you?"

# --- Shutdown Handling ---
async def shutdown():
    print("Shutting down...")
    try:
        if hasattr(client, 'close') and callable(client.close):
            await client.close()
            print("CharacterAI client closed")
    except Exception as e:
        print(f"Error closing client: {e}")
    print("Shutdown complete.")

def on_closing():
    global running
    running = False
    print("Closing application...")

    async def _close():
        await shutdown()
        root.destroy()

    asyncio.create_task(_close())

send_button.config(command=send_message)
message_entry.bind("<Return>", lambda event: send_message())
root.protocol("WM_DELETE_WINDOW", on_closing)

def check_libraries():
    required_libraries = ['tkinter', 'PIL', 'asyncio', 'characterai', 'sqlite3', 'textblob']
    missing_libraries = []

    for lib in required_libraries:
        try:
            importlib.import_module(lib)
        except ImportError:
            missing_libraries.append(lib)

    return missing_libraries

def install_libraries(missing_libraries):
    try:
        subprocess.check_call(['pip', 'install', *missing_libraries])
        print("Libraries installed successfully!")
        return True  # Indicate successful installation
    except subprocess.CalledProcessError as e:
        print(f"Error installing libraries: {e}")
        return False # Installation failed

def create_loading_window():
    loading_window = tk.Toplevel(root) # Creates a child window
    loading_window.title("Installing Libraries...")
    loading_window.geometry("300x150")

    label = tk.Label(loading_window, text="Installing required libraries...", font=("Arial", 12))
    label.pack(pady=20)

    progressbar = tk.ttk.Progressbar(loading_window, mode='indeterminate')
    progressbar.pack(pady=10, fill=tk.X, padx=20)
    progressbar.start()

    return loading_window

# --- Tkinter with Asyncio Support ---
async def main():

    missing = check_libraries()
    if missing:

        print("Missing libraries: ", missing)
        print("Attempting to install...")

        loading_window = create_loading_window()

        install_success = install_libraries(missing)
        loading_window.destroy()  #Close window regardless of install

        if not install_success:
            messagebox.showerror("Error", "Please install the required libraries to launch Hu Tao Director AI!")
            root.destroy()
            sys.exit()  #ensure script stop
        else:
            messagebox.showinfo("Info", "Libraries intalled, Please re-run to see changes!") #restart for code load

            sys.exit()  #quit instead since library require another start.


    else:
        print("All required libraries are installed.")

    await initialize_db()
    global client, last_interaction_time, user_affection
    client = aiocai.Client('8d9d7d0d89c48642e440e66e2590256f7dc0e3ef')  # Replace with your key
    user_id = 1
    chat_id, conversation_history = await get_chat_session(user_id)

    first_message_sent = False
    global current_activity, activity_start_time, USER_NAME, user_introduced

    USER_NAME = DEFAULT_USER_NAME   #IMPORTANT if session exit and come back for default Altair to properly initialized!
    choose_activity() # Initialize the activity when the bot starts

    global emotion_label, current_emotion
    current_emotion = "Neutral"

    user_affection = DEFAULT_AFFECTION  # Initialize affection when the bot starts

    while running:
        user_id = 1
        chat_id, conversation_history = await get_chat_session(user_id)

        if not chat_id and not first_message_sent:
            initial_message = "Heya. I'm the 77th Director of the Wangsheng Funeral Parlor, Hu Tao. Are you one of my clients?"
            update_chat_log(f"Hu Tao: {initial_message}", sender="hutao")
            first_message_sent = True
            new_chat = await client.connect()
            new_chat, _ = await new_chat.new_chat(CHAR_ID, (await client.get_me()).id)
            chat_id = new_chat.chat_id
            conversation_history = [f"Hu Tao: {initial_message}"]
            await save_chat_session(user_id, chat_id, conversation_history)

        elif not chat_id and first_message_sent:
            print("New Session. Please Wait...")

        try:
            current_time = asyncio.get_event_loop().time()
            if current_time - last_interaction_time > IDLE_TIMEOUT:
                last_interaction_time = current_time

                idle_message = await generate_idle_response(user_id)

                chat_id, conversation_history = await get_chat_session(user_id)
                conversation_history.append(f"Hu Tao: {idle_message}")
                await save_chat_session(user_id, chat_id, conversation_history)

                update_chat_log(f"Hu Tao: {idle_message}", sender="hutao")

                display_conversation()

            root.update()
            await asyncio.sleep(0.01)
        except tk.TclError:
            break

    print("Main loop terminated.")

if __name__ == "__main__":
    # Ensure Tkinter is initialized *before* checking libraries
    import tkinter.ttk as ttk

    asyncio.run(main())