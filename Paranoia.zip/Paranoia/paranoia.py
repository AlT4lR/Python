import tkinter as tk
from PIL import Image, ImageTk, ImageDraw
import asyncio
from characterai import aiocai
from database import initialize_db, save_chat_session, get_chat_session  # Import DB functions

# --- CharacterAI Setup ---
client = aiocai.Client('8d9d7d0d89c48642e440e66e2590256f7dc0e3ef')  # Replace with your actual key

# --- Tkinter Setup ---
root = tk.Tk()
root.title("Director Hu Tao")
root.geometry("800x600")

# --- Frames ---
main_frame = tk.Frame(root)
main_frame.pack(fill=tk.BOTH, expand=True)

# --- Chat Log ---
chat_frame = tk.Frame(main_frame, bg="black")
chat_frame.pack(fill=tk.BOTH, expand=True)

chat_log = tk.Text(chat_frame, bg="black", fg="lightgreen", wrap=tk.WORD, state=tk.DISABLED)
chat_log.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

# --- Input Area ---
input_frame = tk.Frame(main_frame, bg="black")
input_frame.pack(side=tk.BOTTOM, fill=tk.X)

message_entry = tk.Entry(input_frame, bg="black", fg="white", font=("Courier New", 12))
message_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=10, pady=10)

send_button = tk.Button(input_frame, text="Send", bg="gray", fg="white", font=("Arial", 12), padx=10, pady=5)
send_button.pack(side=tk.RIGHT, padx=10, pady=10)

# --- Hu Tao Info ---
info_frame = tk.Frame(chat_frame, bg="black")
info_frame.pack(side=tk.TOP, fill=tk.X)

def create_circular_image(image_path, size):
    """Create a circular image from the given image path."""
    # Open the image and resize it
    image = Image.open(image_path).resize(size)

    # Create a mask for the circular shape
    mask = Image.new("L", size, 0)
    draw = ImageDraw.Draw(mask)
    draw.ellipse((0, 0, size[0], size[1]), fill=255)

    # Apply the mask to the image
    circular_image = Image.new("RGBA", size)
    circular_image.paste(image, (0, 0), mask=mask)

    return circular_image

try:
    img_path = "assets/hutao.jpg"  # Ensure the image path is correct
    circular_image = create_circular_image(img_path, (75, 75))  # Create circular image
    photo = ImageTk.PhotoImage(circular_image)
    image_label = tk.Label(info_frame, image=photo, bg="black")
    image_label.image = photo
    image_label.pack(side=tk.LEFT, padx=10, pady=10)
except FileNotFoundError:
    print(f"Image not found: {img_path}")

name_label = tk.Label(info_frame, text="Hu Tao", font=("Baskerville", 22), bg="black", fg="white")
name_label.pack(side=tk.LEFT, pady=10)

# --- CharacterAI Functions with DB Integration ---
async def handle_characterai_command(user_id, message):
    try:
        char_id = "UDNCEQ52KFps5uH8v_MArnhjjafp1M1vNiRJfd7l-68"  # Your character ID

        chat_id, conversation_history = await get_chat_session(user_id)
        chat = await client.connect()  # Connect *once* per message

        if not chat_id:
            new_chat, _ = await chat.new_chat(char_id, (await client.get_me()).id)
            chat_id = new_chat.chat_id
            await save_chat_session(user_id, chat_id, [])

        # Send message with history
        full_message = "\n".join(conversation_history + [message]) if conversation_history else message
        response = await chat.send_message(char_id, chat_id, full_message)

        conversation_history.append(f"You: {message}")
        conversation_history.append(f"Hu Tao: {response.text}")
        await save_chat_session(user_id, chat_id, conversation_history)

        return response.text

    except Exception as e:
        print(f"Error generating content: {e}")
        return f"Error: {e}"

# --- Chat Handling ---
def update_chat_log(message, sender="user"):
    chat_log.config(state=tk.NORMAL)
    if sender == "hutao":
        chat_log.insert(tk.END, message + "\n", "hutao")
    else:
        chat_log.insert(tk.END, message + "\n")
    chat_log.tag_config("hutao", foreground="#D2B48C")  # Brown color for Hu Tao
    chat_log.see(tk.END)
    chat_log.config(state=tk.DISABLED)

def send_message():
    user_message = message_entry.get().strip()
    if user_message:
        update_chat_log(f"You: {user_message}")
        message_entry.delete(0, tk.END)
        asyncio.create_task(process_response(user_message))

async def process_response(message):
    user_id = 1  # Simulated user ID since this is a local app
    response = await handle_characterai_command(user_id, message)
    update_chat_log(f"Hu Tao: {response}", sender="hutao")

send_button.config(command=send_message)
message_entry.bind("<Return>", lambda event: send_message())

# --- Tkinter with Asyncio Support ---
async def main():
    await initialize_db()
    global client
    client = aiocai.Client('8d9d7d0d89c48642e440e66e2590256f7dc0e3ef')  # Your actual key
    while True:
        try:
            root.update()
            await asyncio.sleep(0.01)
        except tk.TclError:
            break

if __name__ == "__main__":
    asyncio.run(main())